
package part.pkg2.test;


import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testCheckTaskDescription() {
        Task task = new Task("TaskName", 1, "A valid task description", "John Doe", 5, "To Do");
        assertTrue(task.checkTaskDescription());

        Task taskWithLongDescription = new Task("TaskName", 2, "A very long task description that exceeds the fifty character limit imposed by the system.", "Jane Doe", 3, "In Progress");
        assertFalse(taskWithLongDescription.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        String expectedTaskID = "TA:1:DOE";
        assertEquals(expectedTaskID, task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        String expectedDetails = "Task Status: To Do\n" +
                                 "Developer Details: John Doe\n" +
                                 "Task Number: 1\n" +
                                 "Task Name: TaskName\n" +
                                 "Task Description: A task description\n" +
                                 "Task ID: TA:1:DOE\n" +
                                 "Duration: 5hrs";
        assertEquals(expectedDetails, task.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours() {
        Task task = new Task("TaskName", 1, "A task description", "John Doe", 5, "To Do");
        assertEquals(5, task.returnTotalHours());
    }
}

