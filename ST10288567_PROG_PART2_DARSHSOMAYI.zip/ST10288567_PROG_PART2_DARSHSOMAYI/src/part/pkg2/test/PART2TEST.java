/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part.pkg2.test;
/**
 *
 * @author Darsh Somayi
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class PART2TEST {

    
    public static void main(String[] args) {
        Register register = new Register();
        Login login = new Login();

        register.registerUser(); // Step 1: Register a new user
        boolean loginSuccess = login.loginUser(register.getUsername(), register.getPassword()); // Step 2: Login to the account

        // Step 2a: Display appropriate message based on login success
        if (loginSuccess) {
            JOptionPane.showMessageDialog(null, "Welcome " + register.getFirstName() + " " + register.getLastName() + ", it is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
        }


        ArrayList<Task> tasks = new ArrayList<>();

        register.registerUser(); // Step 1: Register a new user
       

        // Step 2a: Display appropriate message based on login success
        if (loginSuccess) {
            JOptionPane.showMessageDialog(null, "Welcome " + register.getFirstName() + " " + register.getLastName() + ", it is great to see you again.");
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

            // Step 3: Display menu and handle user choices
            boolean quit = false;
            while (!quit) {
                String menu = "Please choose an option:\n1) Add tasks\n2) Show report\n3) Quit";
                String choice = JOptionPane.showInputDialog(null, menu);

                switch (choice) {
                    case "1":
                        addTasks(tasks);
                        break;
                    case "2":
                        JOptionPane.showMessageDialog(null, "Coming Soon");
                        break;
                    case "3":
                        quit = true;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                }
            }

        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
        }
    }

    private static void addTasks(ArrayList<Task> tasks) {
        String numTasksStr = JOptionPane.showInputDialog(null, "Enter the number of tasks:");
        int numTasks = Integer.parseInt(numTasksStr);

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");
            String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details:");
            String taskDurationStr = JOptionPane.showInputDialog(null, "Enter task duration (in hours):");
            int taskDuration = Integer.parseInt(taskDurationStr);
            String[] statuses = {"To Do", "Done", "Doing"};
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:", "Task Status", JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

            Task task = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);

            if (task.checkTaskDescription()) {
                tasks.add(task);
                JOptionPane.showMessageDialog(null, "Task successfully captured");
                JOptionPane.showMessageDialog(null, task.printTaskDetails());
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                i--; // retry current task
            }
        }

        int totalHours = tasks.stream().mapToInt(Task::returnTotalHours).sum();
        JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);
    }
}



    
    

