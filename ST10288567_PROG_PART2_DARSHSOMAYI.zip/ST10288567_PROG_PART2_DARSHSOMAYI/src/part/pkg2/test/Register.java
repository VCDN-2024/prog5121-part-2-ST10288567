/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg2.test;

/**
 *
 * @author Darsh Somayi
 */
import javax.swing.JOptionPane;


public class Register {
    
    String username;
    private String password;
    private String firstName;
    private String lastName;

    // Method to register a new user
    public void registerUser() {
        boolean isRegistered = false;
        while (!isRegistered) {
            username = JOptionPane.showInputDialog(null, "Enter username:");
            password = JOptionPane.showInputDialog(null, "Enter password:");
            firstName = JOptionPane.showInputDialog(null, "Enter first name:");
            lastName = JOptionPane.showInputDialog(null, "Enter last name:");

            // Check username and password format
            boolean isUsernameCorrect = checkUserName();
            boolean isPasswordCorrect = checkPasswordComplexity();

            if (isUsernameCorrect && isPasswordCorrect) {
                isRegistered = true;
                int option = JOptionPane.showConfirmDialog(null, "Correct username and password. Proceed to the sign-in page?", "Success", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.NO_OPTION) {
                    isRegistered = false; // If user chooses no, reset registration process
                }
            } else {
                JOptionPane.showMessageDialog(null, "Registration failed. Please check username and password format.");
            }
        }
    }

    // Method to check username format
    private boolean checkUserName() {
        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return false;
        }
    }

    // Method to check password complexity
    private boolean checkPasswordComplexity() {
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        if (password.matches(regex)) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            return false;
        }
    }

    // Getters for username, password, first name, and last name
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    
}
