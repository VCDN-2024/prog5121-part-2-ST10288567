/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg2.test;

/**
 *
 * @author Darsh Somayi
 */
public class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    // Constructor
    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }

    // Check if task description is valid
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    // Create Task ID
    public String createTaskID() {
        String devInitials = developerDetails.split(" ")[1].substring(0, 3).toUpperCase();
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + devInitials;
    }

    // Return task details
    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Duration: " + taskDuration + "hrs";
    }

    // Return task duration
    public int returnTotalHours() {
        return taskDuration;
    }
}
