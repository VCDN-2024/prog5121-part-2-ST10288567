/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part.pkg2.test;
/**
 *
 * @author Darsh Somayi
 */
import javax.swing.JOptionPane;

public class Login {
    
    // Method to login user
    public boolean loginUser(String registeredUsername, String registeredPassword) {
        String inputUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String inputPassword = JOptionPane.showInputDialog(null, "Enter your password:");
        return inputUsername.equals(registeredUsername) && inputPassword.equals(registeredPassword);
    }
}
